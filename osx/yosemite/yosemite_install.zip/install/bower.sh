#! /bin/bash

sudo npm install bower -g