#! /bin/bash

sudo npm install gulp -g