#! /bin/bash

git clone git@github.com:NukaCode/dasher.git $siteDir