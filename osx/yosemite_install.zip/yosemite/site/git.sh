#! /bin/bash

git clone https://github.com/NukaCode/dasher.git $siteDir