#!/bin/bash

sudo npm install npm -g