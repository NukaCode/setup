#! /bin/bash

brew update && brew upgrade