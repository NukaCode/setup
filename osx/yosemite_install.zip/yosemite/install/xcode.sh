#! /bin/bash

xcode-select --install