#! /bin/bash

curl -L https://nodejs.org/dist/v0.12.5/node-v0.12.5.pkg -o ~/Downloads/node.pkg

sudo installer -pkg ~/Downloads/node.pkg -target /