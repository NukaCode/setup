#! /bin/bash

# Snag the nuka installer
composer global require "laravel/envoy"